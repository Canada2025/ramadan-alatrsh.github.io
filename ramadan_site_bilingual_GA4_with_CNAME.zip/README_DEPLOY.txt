==============================
Deployment Instructions
==============================

This package contains your bilingual academic website for **Ramadan Alatrsh** with:
- GA4 tracking ID: G-VHM6F2GQDX
- Email: ralatrsh@unb.ca
- Portrait and embedded CV.pdf

-------------------------------------
Option 1: Deploy on GitHub Pages
-------------------------------------
1. Go to https://github.com/new and create a repository named:
      ramadan-alatrsh.github.io

2. Upload all files from this package (index.html, cv.pdf, portrait.jpg, README.md).

3. Commit and go to Settings → Pages → Deploy from “main” branch → /(root).

4. After a minute, your site will be live at:
      https://ramadan-alatrsh.github.io

5. Verify Analytics works:
   - Visit your site.
   - In GA4 → “Reports → Realtime” you should see yourself as a visitor.

-------------------------------------
Option 2: Host on UNB or another web server
-------------------------------------
1. Send the files to your department IT or upload via FTP/SFTP to your faculty web directory.
2. The site can run as-is; no build step required (pure HTML).
3. Verify that https://your-unb-address/index.html loads correctly.

-------------------------------------
Optional Improvements
-------------------------------------
- Replace portrait.jpg with a higher-resolution photo (same filename).
- Replace cv.pdf with your full academic CV.
- Update index.html with new publications or teaching info anytime.
- To add a favicon, replace the inline SVG in the <head> tag.
- To test Analytics, use Chrome → Extensions → Google Tag Assistant.

-------------------------------------
PhilPeople Linking
-------------------------------------
1. Visit https://philpeople.org/profiles/ramadan-alatrsh/edit
2. Under “External Links” → Add Website
3. Paste your site URL (e.g., https://ramadan-alatrsh.github.io/?utm_source=philpeople&utm_medium=profile&utm_campaign=cv_link)
4. Save and test the link.

-------------------------------------
Support
-------------------------------------
If you need to update GA ID or links again, open index.html and search for:
   G-VHM6F2GQDX
   ralatrsh@unb.ca
Then edit and save.
